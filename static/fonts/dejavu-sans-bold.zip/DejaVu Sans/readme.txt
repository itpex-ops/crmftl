Your font download is ready.

Before installing it, extract the ZIP archive and read any included licence or readme file. A free download does not always include permission for commercial work, websites, apps, logos or redistribution.


How to install the font

Windows 11 and Windows 10:

- Select the extracted TTF or OTF files, right-click and choose “Install”. Choose “Install for all users” if every account on the computer should have access; administrator permission may be required.

- You can also open Settings > Personalization > Fonts and drag the files into the font installation area.

macOS:

- Double-click the extracted font file, review the preview in Font Book and choose “Install”. Font Book validates and adds the font to your library.

Linux:

- Copy the font files to ~/.local/share/fonts for your account, or /usr/share/fonts for all users, then run fc-cache -f -v if your desktop does not refresh the font list automatically.

If the font is missing from an application that was already open, restart that application. For more help, visit the Fonts2u FAQ.